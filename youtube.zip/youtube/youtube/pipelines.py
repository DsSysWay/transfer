# -*- coding: utf-8 -*-
from __future__ import unicode_literals
# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


from scrapy import signals
import json
from youtube.misc.log  import *
import codecs
import sys
import redis

reload(sys)
sys.setdefaultencoding('utf-8')



class YoutubePipeline(object):
    server = redis.Redis('localhost')


    def process_item(self, item, spider):
        geo = item['geo']
        country = item['country']
        info("pipeline youtube:"+geo+"---->"+ country)
        data = item['data'].encode("utf-8")
        filename = './hot/' + country
        ###传进去前最好是先编码为utf－8
        filename = filename.encode("utf-8")
        tmpFile = codecs.open(filename, 'w', encoding='utf-8')
        tmpFile.write(data)
        tmpFile.flush()
        tmpFile.close()
        self.server.set(country,data)


        return item


