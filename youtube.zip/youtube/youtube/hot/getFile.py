import json


data = ''
with open("Australia",'r')  as f:
    data = f.read()

if(len(data)!= 0):
    decode = json.loads(data)
    print type(decode)
    print "date:",decode['date']
    print "formattedDate:",decode['formattedDate']
    print 'list len:',len(decode['videoList'])




