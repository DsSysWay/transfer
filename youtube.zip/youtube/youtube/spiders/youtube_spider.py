#coding="utf-8"
import  re
import json


from scrapy.selector import Selector
from scrapy.mail import MailSender
import scrapy
try:
    from scrapy.spider import Spider
except:
    from scrapy.spider import BaseSpider as Spider
from scrapy.utils.response import get_base_url
from scrapy.utils.url import urljoin_rfc
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor as sle

from youtube.misc.log import *
from youtube.items import *
import logging
from scrapy.log import ScrapyFileLogObserver

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText

from scrapy import signals
from scrapy.xlib.pydispatch import dispatcher


import codecs
import sys
reload(sys)
sys.setdefaultencoding('utf-8')




logfile = open("testlog.log",'w')
log_observer = ScrapyFileLogObserver(logfile,level = logging.INFO)
log_observer.start()

class youtubeSpider(CrawlSpider):
    geoDict = {'AR':'Argentina','AU':'Australia','BR':'Braliz','CA':'Canada',
            'EG':'Egypt','FR':'France','DE':'Germany','GR':'Greece',
            'IN':'India','IT':'Italy','JP':'Japan','MX':'Mexico',
            'MA':'Morocco','NL':'Netherlands','PH':'Philippines',
            'PL':'Poland','RU':'Russia','SA':'Saudi Arabia','KR':'South Korea',
            'ES':'Spain','SE':'Sweden','TW':'Taiwan','TH':'Thailand',
            'TR':'Turkey','UA':'Ukraine','GB':'United Kingdom',
            'US':'United States'} 
    parseDict = {'AR':'Argentina','AU':'Australia','BR':'Braliz','CA':'Canada',
            'EG':'Egypt','FR':'France','DE':'Germany','GR':'Greece',
            'IN':'India','IT':'Italy','JP':'Japan','MX':'Mexico',
            'MA':'Morocco','NL':'Netherlands','PH':'Philippines',
            'PL':'Poland','RU':'Russia','SA':'Saudi Arabia','KR':'South Korea',
            'ES':'Spain','SE':'Sweden','TW':'Taiwan','TH':'Thailand',
            'TR':'Turkey','UA':'Ukraine','GB':'United Kingdom',
            'US':'United States','AU':'Australia'} 

    name = "youtube" #here is the key to name spider,if not match will throw spider not found error
    allowed_domains = ["google.com"]
    start_urls = [
###            "https://www.google.com/trends/hotvideos/hotItems"
            #program zhuan lan
    ]
    rules = [
  ###      Rule(sle(allow=("hotvideos/hotItems")), follow=True, callback='parse_items')
    ]


    def __init__(self):
        dispatcher.connect(self.spider_opened, signal=signals.spider_opened)
        dispatcher.connect(self.spider_closed, signal=signals.spider_closed)


    def start_requests(self):
        return [scrapy.FormRequest("https://www.google.com/trends/hotvideos/hotItems", formdata={'geo':'AR','mob': '0','hvsm':'1'},callback=self.parse_first_url)]

        ### response  can see request as request is a member 
    def parse_first_url(self,response):
        self.parse_items(response)
        for item in self.parseDict:
            yield  scrapy.FormRequest("https://www.google.com/trends/hotvideos/hotItems", formdata={'geo': str(item),'mob': '0','hvsm':'1'},callback=self.parse_items)

    def parse_items(self, response):
        request = response.request
        formData =  str(request.body)
       ### info("*************************************")
        paramsList = formData.split("&") 
        length = len(paramsList)
        geo = ''
        if(length > 0):
            geo = paramsList[length-1]
            ###geo=AR,cut AR out
            geo = geo[4:] 
        ###info("geo:" + geo)
        country = self.geoDict.get(geo)
        if(country == None):
            country = geo
        item = YoutubeItem()
        item['geo']  = geo
        item['country']  = country
        item['data']  = str(response.body)

        return item



    def _process_request(self, request):
        info('process ' + str(request))
        return request

    def spider_opened(self,spider):
        info("spider start")

    def spider_closed(self,spider):
        info("spider close!")
        data = ''
        with  open("testlog.log",'r')  as fp:
             data = fp.read()
        data = data.encode("utf-8")
        self.send_mail(data,'youtube hot video crawler daily report')

    def send_mail(self, message, title):
        info("Sending mail...........")
        gmailUser = '351668465@qq.com'
        gmailPassword = '1234275695'
        recipient = '2630769141@qq.com,935178348@qq.com'

        msg = MIMEMultipart()
        msg['From'] = gmailUser
        msg['To'] = recipient
        msg['Subject'] = title
        msg.attach(MIMEText(message))

        mailServer = smtplib.SMTP('smtp.qq.com', 587)
        mailServer.ehlo()
        mailServer.starttls()
        mailServer.ehlo()
        mailServer.login(gmailUser, gmailPassword)
        mailServer.sendmail(gmailUser, recipient, msg.as_string())
        mailServer.close()
        info("email send") 
